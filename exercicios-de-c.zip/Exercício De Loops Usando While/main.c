#include <stdio.h>

int main()
{
    int i=1;
    
    while(i <= 30){
        printf("%d ",i);
        i++;
        
    }

    return 0;
}
