#include <stdio.h>

int main()
{
   int n1,n2,n3;
   
   printf("Primeiro número:");
   scanf("%d",&n1);
   printf("Segundo número:");
   scanf("%d",&n2);
   printf("Terceiro número:");
   scanf("%d",&n3);
   
   printf("Seus números são: %d || %d || %d",n1,n2,n3);
   printf("\nA soma:%d",n1+n2+n3);
   printf("\nA subtração:%d",n1-n2-n3);
   printf("\nA multiplicação:%d",n1*n2*n3);
   
    return 0;
}





