#include <stdio.h>

int main()
{
    float N1,N2,N3,N4;
    
    printf("Digite a 1ª nota:");
    scanf("%f",&N1);
    
    printf("Digite a 2ª nota:");
    scanf("%f",&N2);
    
    printf("Digite a 3ª nota:");
    scanf("%f",&N3);
    
    printf("A média ponderada é de: %.2f",(N1+N2+N3+N4)/4);
    

    return 0;
}

