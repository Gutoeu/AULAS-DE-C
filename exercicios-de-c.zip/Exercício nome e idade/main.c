#include <stdio.h>

int main(){
    int idade;
    char nome[10];
    
    printf("Digite a sua idade:");
    scanf("%d", &idade);
    
    printf("Digite seu nome:");
    scanf("%s",nome);
    
    printf("\nVocê tem %d anos",idade);
    
    printf("\nSeu nome é %s",nome);
}

