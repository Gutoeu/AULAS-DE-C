#include <stdio.h>

int main()
{
    int n1,n2;
    
    printf("Digite um número:");
    scanf("%d",&n1);
    
    printf("Digite outro número:");
    scanf("%d",&n2);
    
    if(n1==n2){
    printf("Os números são iguais!");
    }
    else{
        printf("Os números são diferentes");
        if(n1>n2){
            printf("\n%d é maior que %d",n1,n2);
        }
        else{
            printf("\n%d é maior que %d",n2,n1);
            }
}

    return 0;
}
