#include <stdio.h>

int main()
{
    int n1,n2,n3;
    
    printf("Digite um valor:");
    scanf("%d",&n1);
    
    printf("Digite um valor:");
    scanf("%d",&n2);
    
    printf("Digite um valor:");
    scanf("%d",&n3);
    
    if(n1<=(n2+n3)&&n2<=(n1+n3)&&n3<=(n2+n3)){
    printf("É um triangulo");
    
    if((n1==n2)&&(n2==n3)){
        printf("\nÉ um triangulo equilátero");
    }
    else{
        if((n1==n2)||(n2==n3)||(n3==n1)){
        printf("\nÉ um triangulo isóceles");
        }
        else{
        printf("\nÉ um triangulo escaleno");
    }
    }
    }
    else{
        printf("\nNão é um triangulo");
    }
    

    return 0;
}



