#include <stdio.h>

int main()
{
   int n1,i;
   
   printf("Digite um número:");
   scanf("%d",&n1);
   i=0;
   printf("\nMenor para maior\n");
   while(i<=n1){
       printf("%d\n",i);
       i++;
   }
   printf("\nMaior para menor\n");
   while(n1>0){
       printf("%d\n",n1);
       n1--;
   }

    return 0;
}


