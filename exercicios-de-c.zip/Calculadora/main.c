#include <stdio.h>

int main()
{
    int opcao,n1,n2;
    printf("****Menu calculadora****\n** 1-SOMA**\n** 2-SUBTRAÇÃO **\n** 3-MULTIPLICAÇÃO **\n** 4-DIVISÃO **\n***************");
    printf("\nEscolha a opcão desejada:");
    scanf("%d",&opcao);
    
    if(opcao>0 && opcao<5){
    
    printf("Digite o primeiro valor:");
    scanf("%d",&n1);
    
    printf("Digite o segundo valor:");
    scanf("%d",&n2);
    
    if(opcao==1){
        printf("A soma dos valores %d e %d é igual a %d",n1,n2,n1+n2);
    }
    if(opcao==2){
            printf("A subtração dos valores %d e %d é igual a %d",n1,n2,n1-n2);
    }
    if(opcao==3){
            printf("A multiplicação dos valores %d e %d é igual a %d",n1,n2,n1*n2);
    }
    if(opcao==4){
            printf("A divisão dos valores %d e %d é igual a %d",n1,n2,n1/n2);
    }
    }
    else{
        printf("\nValor incorreto");
    }

    return 0;
}
