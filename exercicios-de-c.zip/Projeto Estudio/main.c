#include <stdio.h>

int main()
{
    int cor,pagamento,dia,profissional;
    float tamanho_tattoo,horario;
    char imagem[10];
    
    printf("****Formulário de agendamento****\n");
    printf("\n--------------------------------------\n");
    printf("Opções de tamanho: \n(1)5cm (2)10cm (3)15cm (4)+15cm\nDigite:");
    scanf("%f",&tamanho_tattoo);
    printf("\n--------------------------------------\n");

    if(tamanho_tattoo>4 || tamanho_tattoo<1){
        printf("Escolha inválida!!");
        return 0;
    }
    else{
        if (tamanho_tattoo == 1){
            tamanho_tattoo = 5;
        }
        else if (tamanho_tattoo == 2){
            tamanho_tattoo = 10;
        }
         else if (tamanho_tattoo == 3){
            tamanho_tattoo = 15;
        }
         else if (tamanho_tattoo == 4){
            tamanho_tattoo = 15;
        }
    }
    printf("\nOpções de cores\n(1)Preto (2)Colorido\nDigite:");
    scanf("%d",&cor);
    if(cor<1 || cor>2){
        printf("Escolha inválida");
        return 0;
    }
    else{
        if (cor==1){
            imagem = "Preto";
        }
        else if (cor==2){
            imagem = "Colorido";
        }
    }
    printf("\n--------------------------------------\n");
    printf("\nProfissionais disponiveis\n(1)Guilherme (2)Beatriz\nDigite:");
    scanf("%d",&profissional);
    printf("\n--------------------------------------\n");
    
    if(profissional == 1){
        
        printf("****Agenda do tatuador Guilherme****\nDias disponiveis: 1 ao 15\n");
        printf("\nInforme o dia pretendido:");
        scanf("%d",&dia);
        if (dia <1 || dia >15){
            printf("\n--------------------------------------\n");
            printf("\nDia indisponivel na agenda deste tatuador");
            return 0;
        }
    }
    else if (profissional == 2){
        
        printf("**Agenda da tatuadora Beatriz**\nDias disponiveis: 16 ao 30\n");
        printf("\nInforme o dia pretendido:");
        scanf("%d",&dia);
        if (dia <16 || dia >30){
            printf("\n--------------------------------------\n");
            printf("\nDia indisponivel na agenda deste tatuador");
            return 0;
        }
    }
    else{
        printf("Escolha inválida");
        return 0;
    }
    printf("\n--------------------------------------\n");

    if(dia<1 || dia >31){
        printf("Escolha inválida");
        return 0;
    }
    printf("****Horarios das 10hs até as 20hs****\n");
    printf("\nInforme o horário desejado:");
    scanf("%f",&horario);
    if(horario < 10 || horario >20){
        printf("Escolha inválida!!");
        return 0;
    }
    printf("\n--------------------------------------\n");
    printf("\nFormas de pagamento\n(1)PIX\n(2)CARTÃO DE DÉBITO\n(3)CARTÃO DE CRÉDITO\nDigite:");
    scanf("%d",&pagamento);
    if(pagamento<1 || pagamento>3){
        printf("\n--------------------------------------\n");
        printf("\nEscolha inválida");
        return 0;
        
    }
    else{
        printf("\n--------------------------------------\n");
        printf("\nAgendamento concluido!!");
        printf("Tamanho:%d\nCor:%d\nProfissional:%d\nDia:%d\nHora:%d\nForma de pagamento:%d",tamanho_tattoo)
    }
   



    return 0;
}


