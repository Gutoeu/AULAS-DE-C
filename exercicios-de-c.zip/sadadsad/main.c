#include <stdio.h>

int main()
{
    int n1=1,val,contp=0,conti=0,somai=0,somap=0,mediap,mediai;
    
    while(n1!=0){
    printf("Digite um número ou 0 para interromper:");
    scanf("%d",&n1);
    val=val+n1;
    if(n1%2==0){
        if (n1!=0){
        contp++;
        somap=somap+n1;
        mediap=somap/contp;
        }
    }
    else{
        conti++;
        somai=somai+n1;
    }
    }
    mediai=somai/conti;
    printf("\nSoma dos pares:%d",somap);
    printf("\nQuantidade de pares:%d",contp);
    printf("\nMédia dos pares:%d",mediap);
    printf("\nSoma dos impares:%d",somai);
    printf("\nQuantidade de impares:%d",conti);
    printf("\nMédia dos impares:%d",mediai);
    printf("\n%d",contp);
    return 0;
    
    

    
}





