#include <stdio.h>

int main()
{
    float n1,n2,n3,n4,aulas,faltas,corte,exame,media;
    
    printf("Digite o total de aulas:");
    scanf("%f",&aulas);
    
    printf("Digite o total de faltas:");
    scanf("%f",&faltas);
    
    printf("Digite sua primeira nota:");
    scanf("%f",&n1);
    
    printf("Digite sua segunda nota:");
    scanf("%f",&n2);
    
    printf("Digite sua terceira nota:");
    scanf("%f",&n3);
    
    printf("Digite sua quarta nota:");
    scanf("%f",&n4);
    
    corte=(faltas/aulas)*100;
    
    if(corte>25){
        printf("\nReprovado por faltas exederem o limite de 25%%");
        printf("\nPorcentagem de faltas: %.2f%%",corte);
        return 0;
    }
    else{
        if((n1>=0 && n1<=10)&&(n2>=0 && n2<=10)&&(n3>=0 && n3<=10)&&(n4>=0 && n4<=10)){
            media=(n1*0.1)+(n2*0.2)+(n3*0.2)+(n4*0.5);
        }
        else{
            printf("Notas inválidas");
            return 0;
        }
    }
    if(media>=7){
        printf("\nVocê foi aprovado!!\nTaxa de faltas: %.2f%%\nMédia: %.2f",corte,media);
    }
    else{
        printf("\nAluno está de Exame!! Com média %.2f",media);
        printf("\nQual sua nota no exame:");
        scanf("%f",&exame);
        if(exame>5){
            printf("\nVocê foi aprovado!!\nTaxa de faltas: %.2f%%\nMédia: %.2f",corte,media);
        }
        else{
            printf("\nVocê foi reprovado\nTaxa de faltas: %.2f%%\nCom média%.2f",corte,exame);
        }
    }

    return 0;
}
