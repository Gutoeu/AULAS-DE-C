#include <stdio.h>

int main(){
    float nota;
    
    printf("Nota de corte: 6.5\n");
    printf("Insira sua nota:");
    scanf("%f",&nota);
    
    if(nota >= 6.5){
        printf("Parabéns você foi aprovado!!");
    }else{
        printf("Sinto muito, você foi reprovado.");
    }
    

    return 0;
}

