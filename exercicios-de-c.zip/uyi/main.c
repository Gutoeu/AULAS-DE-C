#include <stdio.h>

int main()
{
    int tabuada,cont;
    printf("Qual tabuada você deseja:");
    scanf("%d",&tabuada);
    
    cont=0;
    printf("Você escolheu a tabuada do %d\n",tabuada);  
    if(tabuada<=10){
    while(cont<=10){
        printf("%d X %d = %d\n",cont++,tabuada,cont*tabuada);
    }
    }
    else{
        printf("escolha um valor de 1 a 10");
    }

    return 0;
}
 