#include <stdio.h>

int main()
{
    int n1,stop,cont=0;
    while(n1!=0){
    printf("Digite um valor ou 0 para interromper:");
    scanf("%d",&n1);
    if(n1!=0){
        cont++;
    }
    }
    return 0;
}
