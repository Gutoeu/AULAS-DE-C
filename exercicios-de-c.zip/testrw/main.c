#include <stdio.h>

int main()
{
    int idade[3],i;
    
    for(i=0;i<3;i++){
    printf("Digite uma idade:");
    scanf("%d",&idade[i]);
    fflush(stdin);
    }
    
    printf("As idades são:\n");
    for(i=0;i<3;i++){
    printf("%d\n",idade[i]);
    fflush(stdin);
    }

    return 0;
}




