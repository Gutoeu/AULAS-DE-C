#include <stdio.h>

int main()
{
    int opcao,num1,num2;
    do{
        printf("\n***** Menu *****\n");
        printf("1-     SOMA      \n");
        printf("2-   SUBTRAÇÃO   \n");
        printf("3- MULTIPLICAÇÃO \n");
        printf("4-   DIVISÃO    \n");
        printf("5-     SAIR        \n");
        printf("****************\n");
        printf("Digite a opção:");
        scanf("%d",&opcao);
        
        if(opcao==1){
            printf("\nDigite o primeiro número:");
            scanf("%d",&num1);
            
            printf("\nDigite o segundo número:");
            scanf("%d",&num2);
            
            printf("\nA soma dos números %d e %d é igual a:%d",num1,num2,num1+num2);
        }
        else if(opcao==2){
            printf("\nDigite o primeiro número:");
            scanf("%d",&num1);
            
            printf("\nDigite o segundo número:");
            scanf("%d",&num2);
            
            printf("\nA subtração dos números %d e %d é igual a:%d",num1,num2,num1-num2);
        }
        else if(opcao==3){
            printf("\nDigite o primeiro número:");
            scanf("%d",&num1);
            
            printf("\nDigite o segundo número:");
            scanf("%d",&num2);
            
            printf("\nA multiplicação dos números %d e %d é igual a:%d",num1,num2,num1*num2);
        }
        else if(opcao==4){
            printf("\nDigite o primeiro número:");
            scanf("%d",&num1);
            
            printf("\nDigite o segundo número:");
            scanf("%d",&num2);
            
            printf("\nA divisão dos números %d e %d é igual a:%d",num1,num2,num1/num2);
        }
        else if(opcao==5){
            printf("\nSaindo da  calculadora");
            return 0;
        }
        else{
            printf("Número inválido");
        }
        }while(opcao!=0);
}


