
#include <stdio.h>

int main()
{
  
   float quant,macas;
   
    printf("Preço comum: 1.30 R$");
    printf("\nPreço para mais de uma duzia: 1.00 R$\n");
 
    printf("Quantas maçãs você irá comprar:");
    scanf("%f",&quant);
    
    if (quant < 12){
    
    macas = 1.30 * quant;
    printf("\nVc comprou: %.2f maçãs",quant);
    printf("\nCustando: %.2f reais",macas);
    }else{
    macas = quant;
    printf("\nVc comprou: %.2f maçãs",quant);
    printf("\nCustando: %.2f reais",macas);
        
    }
    
    return 0;
}

