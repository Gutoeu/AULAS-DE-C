
#include <stdio.h>

int main()
{
    int n1,n2,n3,media;
    
    printf("Digite um número:");
    scanf("%d",&n1);
    
    printf("Digite outro número:");
    scanf("%d",&n2);
    
    printf("Digite mais outro número:");
    scanf("%d",&n3);

media=(n1+n2+n3)/3;

if(n1==media){
     printf("\n%d é igual a média",n1);
}
else{
    if(n2==media){
        printf("%d é igual a média",n2);
    }else{
        if(n3==media){
        printf("%d é igual a média",n3);
        }else{
            printf("Nenhum é igual");
        }
    }
}
if(n1>media){
    printf("\n%d é maior que a média",n1);
}else{
    if(n2>media){
        printf("\n%d é maior que a média",n2);
    }else{
        if(n3>media){
            printf("\n%d é maior que a média",n3);
        }else{
            printf("\nnenhum é maior");
        }
    }
}
if(n1<media){
    printf("\n%d é menor que a média",n1);
}else{
    if(n2<media){
         printf("\n%d é menor que a média",n2);
    }else{
        if(n3<media){
             printf("\n%d é menor que a média",n3);
        }else{
            printf("Nenhum é menor");
        }
    }
}
    return 0;
}




